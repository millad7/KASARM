# Breaking KASLR on Mobile Devices without Any Use of Cache Memory

This repository demonstrates the implementations of our paper "Breaking KASLR on Mobile Devices without Any Use of Cache Memory". One of the contributions of our paper on Intel CPUs is to break KASLR using the exposed RAPL interface.

## Build

In order to compile our attack, we can use GCC and Make (on Linux). Therefore, we use the following command in a terminal environment:

`make`

## Run

In order to run our attack, the attacker should utilize the following command in a terminal environment:

`sudo ./main`



