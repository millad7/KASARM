#include <stdlib.h>
#include <stdio.h>
#include <stdint.h>
#include <assert.h>
#include <pthread.h>
#include <signal.h>
#include <sys/mman.h>
#include <string.h>
#include <stdbool.h>
#include <setjmp.h>


double delta = 0;
double delta1 = 0;


static sigjmp_buf jbuf;
static void catch_segv()
{
siglongjmp(jbuf, 1);
}


int main()
{
char s;
char mem1[4096 * 256];
memset(mem1, 1, sizeof(mem1));
char *kernel_data1 = (char*)0xfffffffaffffffff; 
for (int u=0; u < 7000; u++){

clock_t tv3 = clock();

signal(SIGSEGV, catch_segv);
if (sigsetjmp(jbuf, 1) == 0) {


*kernel_data1 = 'a';


s = *kernel_data1 + 1;



}
clock_t tv4 = clock();
delta1 += (tv4-tv3);


}

printf ("Address is valid & time is %f\n", delta1);

// '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

char *kernel_data = (char*)NULL;   
char mem[4096 * 256];
memset(mem, 1, sizeof(mem));
for (int u=0; u < 7000; u++){

clock_t tv1 = clock();

signal(SIGSEGV, catch_segv);
if (sigsetjmp(jbuf, 1) == 0) {


*kernel_data = 'a';


s = *kernel_data + 1;



}
clock_t tv2 = clock();
delta += (tv2-tv1);


}

printf ("Address is invalid & time is %f\n", delta);

// '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''



return 0;
}
